var searchData=
[
  ['sauvgtxt_18',['SauvgTxt',['../class_sauvg_txt.html',1,'']]],
  ['segment_19',['Segment',['../class_segment.html',1,'']]]
];
