var searchData=
[
  ['triangle_20',['Triangle',['../class_triangle.html',1,'']]]
];
