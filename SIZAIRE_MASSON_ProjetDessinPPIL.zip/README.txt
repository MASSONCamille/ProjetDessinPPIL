--------------------------------------------------------------------
| ProjetDessinClient	--> Projet C++ VisualStudio 2017	   |
| ProjetDessinServeur	--> Projet Eclipse			   |
| Rapport		--> Rapport de projet + Annexe fichier UML |
--------------------------------------------------------------------

DOC C++		--> ProjetDessinClient/ProjetDessinClient/html
DOC JAVA	--> ProjetDessinServeur/doc

Client Executable	--> ProjetDessinClient/x64/Debug

Lien GitHub	--> https://github.com/MASSONCamille/ProjetDessinPPIL